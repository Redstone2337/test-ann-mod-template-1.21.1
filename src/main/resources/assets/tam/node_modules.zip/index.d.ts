// Minecraft Brewing Types - Main entry point
// Provides complete TypeScript definitions for Minecraft brewing recipe development

/// <reference path="./types/core.d.ts" />
/// <reference path="./types/builders.d.ts" />

export {};

// Global augmentation for IntelliSense support
declare global {
  // Re-export main brewing function
  function brew(recipe: BrewingRecipe): void;
  
  // BrewingRecipeEvent namespace with create method
  namespace BrewingRecipeEvent {
    function create(callback: (e: BrewingRecipeEvent) => void): void;
  }

  // Constants declarations - only declared here
  const Items: {
    readonly POTION: 'potion';
    readonly SPLASH_POTION: 'splash_potion';
    readonly LINGERING_POTION: 'lingering_potion';
    readonly GUNPOWDER: 'gunpowder';
    readonly DRAGON_BREATH: 'dragon_breath';
    readonly EMERALD: 'emerald';
    readonly GLOWSTONE_DUST: 'glowstone_dust';
    readonly REDSTONE: 'redstone';
    readonly FERMENTED_SPIDER_EYE: 'fermented_spider_eye';
    readonly NETHER_WART: 'nether_wart';
    readonly OBSIDIAN: 'obsidian';
    readonly BLAZE_POWDER: 'blaze_powder';
    readonly GHAST_TEAR: 'ghast_tear';
    readonly MAGMA_CREAM: 'magma_cream';
    readonly GOLDEN_CARROT: 'golden_carrot';
    readonly SPIDER_EYE: 'spider_eye';
    readonly SUGAR: 'sugar';
    readonly RABBIT_FOOT: 'rabbit_foot';
    readonly PHANTOM_MEMBRANE: 'phantom_membrane';
    readonly TURTLE_HELMET: 'turtle_helmet';
    [key: string]: string;
  };

  const Potions: {
    readonly WATER: 'water';
    readonly AWKWARD: 'awkward';
    readonly THICK: 'thick';
    readonly MUNDANE: 'mundane';
    readonly NIGHT_VISION: 'night_vision';
    readonly LONG_NIGHT_VISION: 'long_night_vision';
    readonly INVISIBILITY: 'invisibility';
    readonly LONG_INVISIBILITY: 'long_invisibility';
    readonly LEAPING: 'leaping';
    readonly LONG_LEAPING: 'long_leaping';
    readonly STRONG_LEAPING: 'strong_leaping';
    readonly SWIFTNESS: 'swiftness';
    readonly LONG_SWIFTNESS: 'long_swiftness';
    readonly STRONG_SWIFTNESS: 'strong_swiftness';
    readonly SLOWNESS: 'slowness';
    readonly LONG_SLOWNESS: 'long_slowness';
    readonly STRONG_SLOWNESS: 'strong_slowness';
    readonly TURTLE_MASTER: 'turtle_master';
    readonly LONG_TURTLE_MASTER: 'long_turtle_master';
    readonly STRONG_TURTLE_MASTER: 'strong_turtle_master';
    readonly WATER_BREATHING: 'water_breathing';
    readonly LONG_WATER_BREATHING: 'long_water_breathing';
    readonly HEALING: 'healing';
    readonly STRONG_HEALING: 'strong_healing';
    readonly HARMING: 'harming';
    readonly STRONG_HARMING: 'strong_harming';
    readonly POISON: 'poison';
    readonly LONG_POISON: 'long_poison';
    readonly STRONG_POISON: 'strong_poison';
    readonly REGENERATION: 'regeneration';
    readonly LONG_REGENERATION: 'long_regeneration';
    readonly STRONG_REGENERATION: 'strong_regeneration';
    readonly STRENGTH: 'strength';
    readonly LONG_STRENGTH: 'long_strength';
    readonly STRONG_STRENGTH: 'strong_strength';
    readonly WEAKNESS: 'weakness';
    readonly LONG_WEAKNESS: 'long_weakness';
    readonly LUCK: 'luck';
    readonly SLOW_FALLING: 'slow_falling';
    readonly LONG_SLOW_FALLING: 'long_slow_falling';
    [key: string]: string;
  };

  const DataComponentTypes: {
    readonly POTION_CONTENTS: 'potion_contents';
    readonly CUSTOM_DATA: 'custom_data';
    readonly [key: string]: string;
  };
}
