// Minecraft Core Type Definitions
// 此文件保持原样，用于向后兼容

declare namespace Minecraft {
  // 物品相关
  interface Item {
    id: string;
    name: string;
  }

  // 药水相关
  interface Potion {
    id: string;
    name: string;
    effects: StatusEffect[];
  }

  interface StatusEffect {
    type: string;
    duration: number;
    amplifier: number;
  }

  // 酿造台配方
  interface BrewingRecipe {
    input: BrewingIngredient;
    material: BrewingIngredient;
    output: BrewingIngredient;
  }

  interface BrewingIngredient {
    item: string;
    potion?: string;
    components?: Record<string, any>;
  }
}

// Fabric API 类型
declare namespace FabricAPI {
  interface BrewingRecipeEvent {
    input: BrewingIngredientBuilder;
    material: BrewingIngredientBuilder;
    output: BrewingIngredientBuilder;
  }

  interface BrewingIngredientBuilder {
    add(item: string): BrewingComponentBuilder;
  }

  interface BrewingComponentBuilder {
    component(componentType: string, value: string): BrewingComponentBuilder;
    toCreateBrewing(): void;
  }
}

export {};