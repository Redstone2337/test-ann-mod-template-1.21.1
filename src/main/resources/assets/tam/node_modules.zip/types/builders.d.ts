// ==================== 构建器类型定义 ====================

/**
 * 酿造配方事件接口
 */
interface BrewingRecipeEvent {
  input: BrewingIngredientBuilder;
  material: BrewingIngredientBuilder;
  output: BrewingIngredientBuilder;
}

interface BrewingIngredientBuilder {
  /**
   * 添加基础物品
   * @param item 物品ID或Items常量
   */
  add(item: string | ItemConstant): BrewingComponentBuilder;
}

interface BrewingComponentBuilder {
  /**
   * 添加数据组件
   * @param componentType 组件类型，如 DataComponentTypes.POTION_CONTENTS
   * @param value 组件值，如药水类型或自定义值
   */
  component(componentType: string | DataComponentTypeConstant, value: string | PotionConstant): BrewingComponentBuilder;
  
  /**
   * 完成配方创建
   */
  toCreateBrewing(): void;
}

/**
 * 酿造配方事件命名空间
 */
declare namespace BrewingRecipeEvent {
  /**
   * 创建酿造配方
   * @param callback 配方配置回调函数
   */
  function create(callback: (e: BrewingRecipeEvent) => void): void;
}

/**
 * 简化格式酿造配方注册函数
 * @param recipe 简化格式配方对象
 */
declare function brew(recipe: BrewingRecipe): void;
