// ==================== 核心类型定义 ====================

/**
 * 酿造配方接口
 */
interface BrewingRecipe {
  input: RecipeIngredient;
  material: RecipeIngredient;
  output: RecipeIngredient;
}

/**
 * 配方原料接口
 */
interface RecipeIngredient {
  item: string;
  potion?: string;
  components?: Record<string, any>;
}

/** 物品常量字面量类型 */
type ItemConstant = 
  | 'potion' | 'splash_potion' | 'lingering_potion' 
  | 'gunpowder' | 'dragon_breath'
  | 'emerald' | 'glowstone_dust' | 'redstone' | 'fermented_spider_eye' | 'nether_wart'
  | 'obsidian' | 'blaze_powder' | 'ghast_tear' | 'magma_cream' | 'golden_carrot'
  | 'spider_eye' | 'sugar' | 'rabbit_foot' | 'phantom_membrane' | 'turtle_helmet'
  | string;

/** 药水常量字面量类型 */
type PotionConstant = 
  | 'water' | 'awkward' | 'thick' | 'mundane' 
  | 'night_vision' | 'long_night_vision'
  | 'invisibility' | 'long_invisibility' 
  | 'leaping' | 'long_leaping' | 'strong_leaping'
  | 'swiftness' | 'long_swiftness' | 'strong_swiftness'
  | 'slowness' | 'long_slowness' | 'strong_slowness'
  | 'turtle_master' | 'long_turtle_master' | 'strong_turtle_master'
  | 'water_breathing' | 'long_water_breathing'
  | 'healing' | 'strong_healing'
  | 'harming' | 'strong_harming'
  | 'poison' | 'long_poison' | 'strong_poison'
  | 'regeneration' | 'long_regeneration' | 'strong_regeneration'
  | 'strength' | 'long_strength' | 'strong_strength'
  | 'weakness' | 'long_weakness' 
  | 'luck' 
  | 'slow_falling' | 'long_slow_falling'
  | string;

/** 数据组件类型字面量 */
type DataComponentTypeConstant = 
  | 'potion_contents'
  | 'custom_data'
  | string;
