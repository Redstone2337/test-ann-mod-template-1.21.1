# Minecraft Brewing Types

#### Complete TypeScript type definitions for Minecraft brewing recipe development with full VSCode IntelliSense support.

## Installation

```bash
npm install --save-dev minecraft-brewing-types
```

### Features


- **🎯 Full TypeScript support with IntelliSense**
- **📝 Complete autocomplete for items, potions, and components**
- **🔧 Two recipe registration styles (traditional and simplified)**
- **🎮 Support for both Fabric API and custom implementations**
- **📚 Comprehensive JSDoc documentation**

### Usage

#### Traditional Style (Fabric API)

```typescript
BrewingRecipeEvent(e => {
  const { input, material, output } = e;
  
  input.add(Items.POTION)
      .component(DataComponentTypes.POTION_CONTENTS, Potions.AWKWARD)
      .toCreateBrewing();
      
  material.add(Items.EMERALD).toCreateBrewing();
  
  output.add(Items.POTION)
      .component(DataComponentTypes.POTION_CONTENTS, 'custom_mod:luck_potion')
      .toCreateBrewing();
});
```

### Simplified Style

```typescript
brew({
  input: { item: Items.POTION, potion: Potions.AWKWARD },
  material: Items.EMERALD,
  output: { item: Items.POTION, potion: 'custom_mod:luck_potion' }
});
```

### Available Constants

#### Items

- **Items.POTION, Items.SPLASH_POTION, Items.LINGERING_POTION**

- **Items.GUNPOWDER, Items.DRAGON_BREATH**

- **Items.EMERALD, Items.GLOWSTONE_DUST, Items.REDSTONE**

- **And many more...**

### Potions

- **Potions.WATER, Potions.AWKWARD, Potions.THICK**
- **Potions.NIGHT_VISION, Potions.INVISIBILITY**
- **Potions.LEAPING, Potions.SWIFTNESS, Potions.STRENGTH**
- **And all vanilla potion types...**

### Data Components

- **DataComponentTypes.POTION_CONTENTS**
- **DataComponentTypes.CUSTOM_DATA**

### VSCode Integration

#### This package provides full IntelliSense support in VSCode:

- **Auto-completion for all constants**
- **Type checking for recipe structures**
- **Hover documentation for all methods and properties**
- **Error highlighting for invalid recipes**

### License

MIT
=======